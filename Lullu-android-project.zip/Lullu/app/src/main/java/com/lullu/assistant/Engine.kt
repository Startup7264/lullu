package com.lullu.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationManagerCompat
import java.util.Locale

// Lullu-r mostisko: shunbe, bujhbe, whitelist-er kaj korbe, bolbe.
class Engine(private val ctx: Context, private val onChange: () -> Unit) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(ctx, this)
    private var recognizer: SpeechRecognizer? = null
    private var pending: (() -> Unit)? = null

    var banglaVoice = false; private set
    var listening = false; private set

    private val aliases = mapOf(
        "হোয়াটসঅ্যাপ" to "whatsapp", "ফেসবুক" to "facebook", "ইউটিউব" to "youtube",
        "ক্রোম" to "chrome", "ক্যামেরা" to "camera", "মেসেঞ্জার" to "messenger",
        "গ্যালারি" to "gallery", "সেটিংস" to "settings", "ক্যালকুলেটর" to "calculator"
    )

    private fun isBn() = Prefs.str(ctx, Prefs.LANG, "bn-BD") == "bn-BD"
    private fun t(bn: String, en: String) = if (isBn()) bn else en

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        var r = tts.setLanguage(Locale("bn", "BD"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = tts.setLanguage(Locale("bn", "IN"))
        }
        banglaVoice = !(r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
        onChange()
    }

    fun shutdown() { recognizer?.destroy(); tts.shutdown() }

    fun say(msg: String) {
        History.add("লুল্লু: $msg")
        if (Prefs.bool(ctx, Prefs.VOICE_REPLY)) {
            if (isBn()) {
                if (banglaVoice) tts.setLanguage(Locale("bn", "BD"))
            } else tts.setLanguage(Locale.US)
            tts.setSpeechRate(Prefs.int(ctx, Prefs.RATE, 10) / 10f)
            tts.speak(msg, TextToSpeech.QUEUE_ADD, null, "lullu")
        }
        onChange()
    }

    // Permission Activity-te check hoy, ekhane dhore nichchi RECORD_AUDIO ache
    fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            say(t("এই ফোনে স্পিচ রিকগনিশন নেই।", "Speech recognition is not available.")); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    listening = false
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text != null) handle(text) else say(t("বুঝতে পারলাম না।", "I did not understand."))
                }
                override fun onError(error: Int) {
                    listening = false
                    say(t("শুনতে পারলাম না, আবার বলো।", "Could not hear you, try again."))
                }
                override fun onReadyForSpeech(p: Bundle?) { listening = true; onChange() }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.str(ctx, Prefs.LANG, "bn-BD"))
        }
        recognizer?.startListening(i)
    }

    // Whitelist: shudhu ei kaj-gulo-i kora jay.
    fun handle(raw: String) {
        val cmd = raw.trim().lowercase(Locale.ROOT)
        if (cmd.isEmpty()) return
        History.add("তুমি: $cmd")
        Prefs.setInt(ctx, Prefs.CMD_COUNT, Prefs.int(ctx, Prefs.CMD_COUNT, 0) + 1)

        pending?.let { p ->
            pending = null
            if (listOf("হ্যাঁ", "হ্যা", "হাঁ", "yes", "ha").any { cmd.contains(it) }) p()
            else say(t("বাতিল করলাম।", "Cancelled."))
            return
        }

        val off = t("এই ফিচারটি বন্ধ আছে।", "This feature is turned off.")
        when {
            cmd.contains("নোটিফিকেশন") || cmd.contains("notification") ->
                if (Prefs.bool(ctx, Prefs.F_NOTIF)) readNotifications() else say(off)
            (cmd.contains("ভলিউম") && cmd.contains("বাড়")) || cmd.contains("volume up") ->
                if (Prefs.bool(ctx, Prefs.F_VOLUME)) volume(true) else say(off)
            (cmd.contains("ভলিউম") && cmd.contains("কম")) || cmd.contains("volume down") ->
                if (Prefs.bool(ctx, Prefs.F_VOLUME)) volume(false) else say(off)
            cmd.contains("খোল") || cmd.startsWith("open") ->
                if (Prefs.bool(ctx, Prefs.F_APPS)) openApp(cmd) else say(off)
            else -> say(t("এই কমান্ড আমি জানি না।", "I do not know this command."))
        }
    }

    private fun readNotifications() {
        val enabled = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        if (!enabled) { say(t("আগে নোটিফিকেশন পারমিশন দাও।", "Please grant notification access first.")); return }
        val list = NotificationStore.latest(Prefs.int(ctx, Prefs.NOTIF_COUNT, 5))
        if (list.isEmpty()) say(t("নতুন কোনো নোটিফিকেশন নেই।", "No new notifications."))
        else {
            say(t("${list.size} টি নোটিফিকেশন আছে।", "You have ${list.size} notifications."))
            list.forEach { say(it) }
        }
    }

    private fun volume(up: Boolean) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        say(if (up) t("ভলিউম বাড়লো।", "Volume up.") else t("ভলিউম কমলো।", "Volume down."))
    }

    private fun openApp(cmd: String) {
        var target = cmd
        aliases.forEach { (bn, en) -> if (cmd.contains(bn)) target = "$target $en" }
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = ctx.packageManager
        val match = pm.queryIntentActivities(launcher, 0)
            .firstOrNull { target.contains(it.loadLabel(pm).toString().lowercase(Locale.ROOT)) }
        val intent = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (match == null || intent == null) { say(t("ওই অ্যাপ খুঁজে পেলাম না।", "App not found.")); return }
        val label = match.loadLabel(pm).toString()
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val launch = { say(t("$label খুলছি।", "Opening $label.")); ctx.startActivity(intent) }
        if (Prefs.bool(ctx, Prefs.CONFIRM_OPEN, false)) {
            pending = launch
            say(t("$label খুলবো? বলো হ্যাঁ।", "Open $label? Say yes."))
        } else launch()
    }
}
