package com.lullu.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

object NotificationStore {
    private val items = ArrayList<String>()
    @Synchronized fun add(s: String) { items.add(s); if (items.size > 30) items.removeAt(0) }
    @Synchronized fun latest(n: Int): List<String> = items.takeLast(n).reversed()
    @Synchronized fun clear() { items.clear() }
}

object History {
    private val items = ArrayList<String>()
    @Synchronized fun add(s: String) { items.add(s); if (items.size > 50) items.removeAt(0) }
    @Synchronized fun latest(n: Int): List<String> = items.takeLast(n).reversed()
    @Synchronized fun clear() { items.clear() }
}

// Shudhu notification poRe memory-te rakhe. Kothao pathay na, kono file-o lekhe na.
class LulluListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName }
        NotificationStore.add("$app: $title $text".trim())
    }
}
