package com.lullu.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var engine: Engine
    private lateinit var chip: TextView
    private lateinit var statusCard: LinearLayout
    private lateinit var notifCard: LinearLayout
    private lateinit var historyCard: LinearLayout
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = Engine(this) { runOnUiThread { refresh() } }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 24),
                Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 32))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            addView(content)
        })

        // Header
        content.addView(Ui.text(this, "লুল্লু", 30f, Ui.TEXT, true))
        content.addView(Ui.text(this, "তোমার পার্সোনাল ভয়েস অ্যাসিস্ট্যান্ট", 13f, Ui.MUTED).apply {
            setPadding(0, 0, 0, Ui.dp(this@MainActivity, 8))
        })
        chip = Ui.text(this, "● প্রস্তুত", 14f, Ui.OK, true).apply {
            setPadding(0, 0, 0, Ui.dp(this@MainActivity, 12))
        }
        content.addView(chip)

        // Mic + text input
        content.addView(Ui.button(this, "🎤  লুল্লুকে বলো") { startListening() })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = Ui.lp(this@MainActivity) }
        input = EditText(this).apply {
            hint = "অথবা এখানে লেখো"
            setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        row.addView(input)
        row.addView(Ui.button(this, "পাঠাও") {
            engine.handle(input.text.toString()); input.setText("")
        }.apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT) })
        content.addView(row)

        // Status
        statusCard = Ui.card(this); content.addView(statusCard)

        // Feature toggles
        val features = Ui.card(this)
        features.addView(Ui.heading(this, "ফিচার"))
        features.addView(Ui.switchRow(this, "নোটিফিকেশন পড়া", "\"নোটিফিকেশন দেখো\"", Prefs.bool(this, Prefs.F_NOTIF)) { Prefs.setBool(this, Prefs.F_NOTIF, it) })
        features.addView(Ui.switchRow(this, "অ্যাপ খোলা", "\"ইউটিউব খোলো\"", Prefs.bool(this, Prefs.F_APPS)) { Prefs.setBool(this, Prefs.F_APPS, it) })
        features.addView(Ui.switchRow(this, "ভলিউম কন্ট্রোল", "\"ভলিউম বাড়াও / কমাও\"", Prefs.bool(this, Prefs.F_VOLUME)) { Prefs.setBool(this, Prefs.F_VOLUME, it) })
        content.addView(features)

        // Planned (honest: not built yet)
        val planned = Ui.card(this)
        planned.addView(Ui.heading(this, "আসছে (এখনো তৈরি হয়নি)"))
        planned.addView(Ui.switchRow(this, "\"লুল্লু\" বলে জাগানো", "Wake word, সবসময় শোনা", false, false) {})
        planned.addView(Ui.switchRow(this, "শুধু আমার ভয়েসে কাজ", "Speaker verification", false, false) {})
        planned.addView(Ui.switchRow(this, "অন্য অ্যাপের ভেতরে কাজ", "Accessibility Service", false, false) {})
        content.addView(planned)

        // Notifications + history
        notifCard = Ui.card(this); content.addView(notifCard)
        historyCard = Ui.card(this); content.addView(historyCard)

        content.addView(Ui.button(this, "⚙  সেটিংস") { startActivity(Intent(this, SettingsActivity::class.java)) })
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onDestroy() { engine.shutdown(); super.onDestroy() }

    private fun hasMic() = ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startListening() {
        if (!hasMic()) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1); return }
        engine.listen()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) engine.listen()
    }

    private fun statusRow(label: String, ok: Boolean, hint: String, onClick: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Ui.dp(this@MainActivity, 6), 0, Ui.dp(this@MainActivity, 6))
            addView(Ui.text(this@MainActivity, "● ", 16f, if (ok) Ui.OK else Ui.BAD))
            addView(Ui.text(this@MainActivity, label, 15f).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(Ui.text(this@MainActivity, if (ok) "চালু" else hint, 13f, if (ok) Ui.MUTED else Ui.BAD))
            if (!ok) setOnClickListener { onClick() }
        }

    private fun refresh() {
        if (!::statusCard.isInitialized) return
        chip.text = if (engine.listening) "● শুনছি…" else "● প্রস্তুত"
        chip.setTextColor(if (engine.listening) Ui.ACCENT else Ui.OK)

        statusCard.removeAllViews()
        statusCard.addView(Ui.heading(this, "স্ট্যাটাস"))
        statusCard.addView(statusRow("মাইক্রোফোন", hasMic(), "চাপো → পারমিশন") {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })
        val notifOn = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        statusCard.addView(statusRow("নোটিফিকেশন অ্যাক্সেস", notifOn, "চাপো → চালু করো") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        statusCard.addView(statusRow("বাংলা ভয়েস (TTS)", engine.banglaVoice, "চাপো → সেটআপ") {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (e: Exception) {}
        })
        statusCard.addView(Ui.text(this, "মোট কমান্ড: ${Prefs.int(this, Prefs.CMD_COUNT, 0)}", 12f, Ui.MUTED).apply {
            setPadding(0, Ui.dp(this@MainActivity, 8), 0, 0)
        })

        notifCard.removeAllViews()
        notifCard.addView(Ui.heading(this, "সাম্প্রতিক নোটিফিকেশন"))
        val n = NotificationStore.latest(5)
        if (n.isEmpty()) notifCard.addView(Ui.text(this, "এখনো কিছু নেই", 13f, Ui.MUTED))
        n.forEach { notifCard.addView(Ui.text(this, "• $it", 13f).apply { setPadding(0, 0, 0, Ui.dp(this@MainActivity, 4)) }) }

        historyCard.removeAllViews()
        historyCard.addView(Ui.heading(this, "কমান্ড হিস্ট্রি"))
        val h = History.latest(12)
        if (h.isEmpty()) historyCard.addView(Ui.text(this, "এখনো কিছু বলা হয়নি", 13f, Ui.MUTED))
        h.forEach { historyCard.addView(Ui.text(this, it, 13f, if (it.startsWith("তুমি")) Ui.TEXT else Ui.MUTED).apply { setPadding(0, 0, 0, Ui.dp(this@MainActivity, 4)) }) }
    }
}
