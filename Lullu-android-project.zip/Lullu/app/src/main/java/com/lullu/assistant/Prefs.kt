package com.lullu.assistant

import android.content.Context

object Prefs {
    const val F_NOTIF = "f_notif"
    const val F_APPS = "f_apps"
    const val F_VOLUME = "f_volume"
    const val VOICE_REPLY = "voice_reply"
    const val CONFIRM_OPEN = "confirm_open"
    const val LANG = "lang"            // "bn-BD" ba "en-US"
    const val RATE = "rate"            // 5..20 (0.5x..2.0x)
    const val NOTIF_COUNT = "notif_count"
    const val CMD_COUNT = "cmd_count"

    private fun sp(c: Context) = c.getSharedPreferences("lullu", Context.MODE_PRIVATE)
    fun bool(c: Context, k: String, d: Boolean = true) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun str(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}
