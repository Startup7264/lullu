package com.lullu.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

object Ui {
    val BG = Color.parseColor("#0F1220")
    val CARD = Color.parseColor("#1A1E33")
    val ACCENT = Color.parseColor("#8B6CFF")
    val TEXT = Color.WHITE
    val MUTED = Color.parseColor("#9AA0B8")
    val OK = Color.parseColor("#2ECC71")
    val BAD = Color.parseColor("#FF5C5C")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, radius: Int = 16) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(c, radius).toFloat()
    }

    fun lp(c: Context, bottom: Int = 12) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 0, 0, dp(c, bottom)) }

    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        background = rounded(c, CARD)
        layoutParams = lp(c)
    }

    fun text(c: Context, s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false) =
        TextView(c).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun heading(c: Context, s: String) = text(c, s, 17f, ACCENT, true).apply {
        setPadding(0, 0, 0, dp(c, 8))
    }

    fun button(c: Context, s: String, onClick: () -> Unit) = Button(c).apply {
        text = s; setTextColor(Color.WHITE); isAllCaps = false
        background = rounded(c, ACCENT, 14)
        layoutParams = lp(c, 8)
        setOnClickListener { onClick() }
    }

    fun switchRow(
        c: Context, label: String, desc: String, checked: Boolean,
        enabled: Boolean = true, onChange: (Boolean) -> Unit
    ): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(c, 6), 0, dp(c, 6))
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(text(c, label, 15f, if (enabled) TEXT else MUTED))
            addView(text(c, desc, 12f, MUTED))
        }
        addView(col)
        addView(SwitchCompat(c).apply {
            isChecked = checked
            isEnabled = enabled
            setOnCheckedChangeListener { _, v -> onChange(v) }
        })
    }
}
