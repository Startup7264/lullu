package com.lullu.assistant

import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@SettingsActivity, 16), Ui.dp(this@SettingsActivity, 24),
                Ui.dp(this@SettingsActivity, 16), Ui.dp(this@SettingsActivity, 32))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(content) })

        content.addView(Ui.text(this, "সেটিংস", 26f, Ui.TEXT, true).apply {
            setPadding(0, 0, 0, Ui.dp(this@SettingsActivity, 12))
        })

        // Language
        val lang = Ui.card(this)
        lang.addView(Ui.heading(this, "ভাষা (শোনা ও বলা)"))
        val group = RadioGroup(this)
        val bn = RadioButton(this).apply { text = "বাংলা"; setTextColor(Ui.TEXT); id = 1001 }
        val en = RadioButton(this).apply { text = "English"; setTextColor(Ui.TEXT); id = 1002 }
        group.addView(bn); group.addView(en)
        group.check(if (Prefs.str(this, Prefs.LANG, "bn-BD") == "bn-BD") 1001 else 1002)
        group.setOnCheckedChangeListener { _, id ->
            Prefs.setStr(this, Prefs.LANG, if (id == 1001) "bn-BD" else "en-US")
        }
        lang.addView(group)
        content.addView(lang)

        // Voice
        val voice = Ui.card(this)
        voice.addView(Ui.heading(this, "ভয়েস"))
        voice.addView(Ui.switchRow(this, "ভয়েসে উত্তর দাও", "বন্ধ থাকলে শুধু লেখা দেখাবে", Prefs.bool(this, Prefs.VOICE_REPLY)) {
            Prefs.setBool(this, Prefs.VOICE_REPLY, it)
        })
        voice.addView(slider("কথা বলার গতি", 5, 20, Prefs.int(this, Prefs.RATE, 10)) {
            Prefs.setInt(this, Prefs.RATE, it); "%.1fx".format(it / 10f)
        })
        content.addView(voice)

        // Safety
        val safe = Ui.card(this)
        safe.addView(Ui.heading(this, "নিরাপত্তা"))
        safe.addView(Ui.switchRow(this, "অ্যাপ খোলার আগে জিজ্ঞেস করো", "\"হ্যাঁ\" বললে তবেই খুলবে", Prefs.bool(this, Prefs.CONFIRM_OPEN, false)) {
            Prefs.setBool(this, Prefs.CONFIRM_OPEN, it)
        })
        content.addView(safe)

        // Notifications
        val notif = Ui.card(this)
        notif.addView(Ui.heading(this, "নোটিফিকেশন"))
        notif.addView(slider("একবারে কতটা পড়বে", 1, 10, Prefs.int(this, Prefs.NOTIF_COUNT, 5)) {
            Prefs.setInt(this, Prefs.NOTIF_COUNT, it); "$it টি"
        })
        content.addView(notif)

        // Data
        val data = Ui.card(this)
        data.addView(Ui.heading(this, "ডেটা"))
        data.addView(Ui.text(this, "সব ডেটা শুধু এই ফোনেই থাকে। নোটিফিকেশন কোথাও পাঠানো হয় না।", 12f, Ui.MUTED))
        data.addView(Ui.button(this, "হিস্ট্রি মুছো") { History.clear() })
        data.addView(Ui.button(this, "সংরক্ষিত নোটিফিকেশন মুছো") { NotificationStore.clear() })
        content.addView(data)

        content.addView(Ui.button(this, "← ড্যাশবোর্ডে ফিরে যাও") { finish() })
    }

    private fun slider(label: String, min: Int, max: Int, value: Int, onChange: (Int) -> String): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val valueText: TextView = Ui.text(this@SettingsActivity, "$label: ${onChange(value)}", 14f)
            addView(valueText)
            addView(SeekBar(this@SettingsActivity).apply {
                this.max = max - min
                progress = value - min
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        valueText.text = "$label: ${onChange(p + min)}"
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
}
